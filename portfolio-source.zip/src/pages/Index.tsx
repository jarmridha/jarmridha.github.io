export { default } from "./IndexRestored";
